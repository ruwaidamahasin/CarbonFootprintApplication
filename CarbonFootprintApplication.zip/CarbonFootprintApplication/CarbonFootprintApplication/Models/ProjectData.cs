﻿namespace CarbonFootprintApplication.Models
{
    public class ProjectData
    {
        public string Name { get; set; }
        public string Location { get; set; }
        public int Duration { get; set; }
        public string Scope { get; set; }
        public float EnergyConsumption { get; set; }
        public float TransportDistance { get; set; }
        public float WasteAmount { get; set; }
    }
    public class FootprintResult
    {
        public float TotalCarbonFootprint { get; set; }
        public float EnergyFootprint { get; set; }
        public float TransportFootprint { get; set; }
        public float WasteFootprint { get; set; }
    }
}
