﻿using Microsoft.AspNetCore.Mvc;
using CarbonFootprintApplication.Models;

namespace CarbonFootprintApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FootprintController : ControllerBase
    {
        [HttpPost("calculate")]
        public ActionResult<FootprintResult> Calculate([FromBody] ProjectData data)
        {
            if (data == null) return BadRequest("Invalid input");

            const float energyFactor = 0.233f;
            const float transportFactor = 0.12f;
            const float wasteFactor = 0.75f;

            var energy = data.EnergyConsumption * energyFactor;
            var transport = data.TransportDistance * transportFactor;
            var waste = data.WasteAmount * wasteFactor;
            var total = energy + transport + waste;

            var result = new FootprintResult
            {
                EnergyFootprint = energy,
                TransportFootprint = transport,
                WasteFootprint = waste,
                TotalCarbonFootprint = total
            };

            return Ok(result);
        }
    }
}
